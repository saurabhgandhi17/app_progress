from core.models import User
from .serializers import RegisterSerializer
from rest_framework import generics
from celery_progress.views import get_progress

# Create your views here.

class CurrentUserViewSet(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer


def task_status(request, task_id):
    # Other checks could go here
    return get_progress(request, task_id)